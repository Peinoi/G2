const SELECT_ALL = `SELECT * FROM users`;

module.exports = { SELECT_ALL };
